﻿#include "PseudorandomGenerator.h"
using namespace std;

//precon: None
//postcon:  Constructs a PseudorandomGenerator object with default values for seed, multiplier, modulus,
//          and increment. It also initializes the random number generator with the seed value.
PseudorandomGenerator::PseudorandomGenerator() : seed(1), multiplier(40), modulus(729), increment(725)
{}

//precon: None
//postcon:  Constructs a PseudorandomGenerator object with parameter values
PseudorandomGenerator::PseudorandomGenerator(int seed, int multiplier, int increment, int modulus)
{
    this->seed = seed;
    this->multiplier = multiplier;
    this->increment = increment;
    this->modulus = modulus;
}

//precon: None
//postcon: Returns the current value of seed
int PseudorandomGenerator::getSeed() const
{
    return seed;
}

//precon: None
//postcon: Sets the value of seed to the provided 'newSeed' value
void PseudorandomGenerator::setSeed(int newSeed)
{
    seed = newSeed;
}

//precon: None
//postcon: Returns the current value of the multiplier
int PseudorandomGenerator::getMultiplier() const
{
    return multiplier;
}

//precon: None
//postcon: Sets the value of multiplier to the provided 'newMultiplier' value
void PseudorandomGenerator::setMultiplier(int newMultiplier)
{
    multiplier = newMultiplier;
}

//precon: None
//postcon: Returns the current value of modulus
int PseudorandomGenerator::getModulus() const
{
    return modulus;
}

//precon: None
//postcon: Sets the value of modulus to the provided 'newModulus' value
void PseudorandomGenerator::setModulus(int newModulus)
{
    modulus = newModulus;
}

//precon: None
//postcon: Returns the current value of increment
int PseudorandomGenerator::getIncrement() const
{
    return increment;
}

//precon: None
//postcon: Sets the value of increment to the provided 'newIncrement' value
void PseudorandomGenerator::setIncrement(int newIncrement)
{
    increment = newIncrement;
}

//precon: None
//postcon: Computes and returns the next pseudorandom number based on the current values of
//         multiplier, increment, modulus, and seed. It also updates the value of seed.
int PseudorandomGenerator::getNextNumber()
{
    seed = (multiplier * seed + increment) % modulus;
    return seed;
}

//precon: None.
//postcon: Computes and returns an indirectly calculated pseudorandom double type number based on the current
//         values of seed, multiplier, increment, and modulus. The function returns a value in the range [0...1).
//         In calling getNextNumber(), this function also updates the value of seed.
double PseudorandomGenerator::getIndirectNextNumber()
{
    return getNextNumber() / (double)modulus;
}

//precon: None
//postcon: The function computes and displays the distribution of numbers returned by the pseudorandom generator for a specified number of iterations,
//         using the provided ranges for multiplier, increment, and modulus.
void PseudorandomGenerator::runExperiment()
{
    int numIterations = 1000000;
    const int numIntervals = 10;
    const double intervalSize = 1.0 / numIntervals;
    vector<int> intervalCounts(numIntervals, 0);

    // Generate random values for multiplier, increment, and modulus + 1 to prevent 0 occurring
    multiplier = rand() + 1;
    increment = rand() + 1;
    modulus = rand() + 1;

    cout << "\n\t\tExperiment of pseudorandom with random multiplier, increment and modulus:";
    cout << "\n\t\t" << string(80, char(196));
    cout << "\n\t\tMultiplier = " << multiplier << ", Increment = " << increment << ", Modulus = " << modulus << "\n\n";
    cout << left << setw(26) << "\t\tRange" << "Number of Occurrences\n";

    //generate random number [0...1) then divide it by .1 and typecast as int to get index in vector, add to count
    for (int i = 0; i < numIterations; i++)
    {
        double randomNumber = getIndirectNextNumber();

        // Calculate interval index and ensure it's within bounds
        int intervalIndex = static_cast<int>(randomNumber / intervalSize);
        intervalIndex = max(0, min(intervalIndex, numIntervals - 1));

        intervalCounts[intervalIndex]++;
    }

    //display interval counts
    for (int i = 0; i < numIntervals; i++)
    {
        double lowerBound = i * intervalSize;
        double upperBound = (i + 1) * intervalSize;
        cout << "\t\t[" << fixed << setprecision(1) << lowerBound << " ... " << upperBound << ")\t\t" << setw(20) << intervalCounts[i] << "\n";
    }


    //get median and standard dev of 12 new generated numbers to calculate next number in gaussian sequence
    double median = 0.0;
    double mean = 0.0;
    double indirect;
    vector<double> nums;
    double sum = 0.0;
    for (int i = 0; i < 12; i++)
    {
        indirect = getIndirectNextNumber();
        sum += indirect;
        nums.push_back(indirect);
    }
    mean = sum / 12;
    sort(nums.begin(), nums.end());
    median = (nums.at(nums.size() / 2) + nums.at((nums.size() / 2) - 1)) / 2.0;

    double sumSD = 0.0;
    for (int i = 0; i < 12; i++)
    {
        sumSD += ((nums.at(i) - mean) * (nums.at(i) - mean));
    }
    double sd = sumSD / 11;

    double gaussianSequence = median + (sum - 6) * sd;


    cout << setprecision(6); // Set precision to 6 decimal places
    cout << "\n\t\tWith 12 uniformly distributed rand numbers in the range [0...1.0),\n";
    cout << "\t\tthe next number in the gaussian sequence is " << gaussianSequence << ".\n";
}